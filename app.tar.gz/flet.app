{
  "name": "علاجي",
  "short_name": "علاجي",
  "display": "standalone",
  "orientation": "portrait",
  "description": "تطبيق طبي",
  "package_name": "com.alaji.app",
  "version": "1.0.0",
  "build_number": "1",
  "platforms": ["android"],
  "icon": {
    "android": "assets/logo.png"
  },
  "android": {
    "min_sdk_version": 21,
    "target_sdk_version": 33
  }
}
